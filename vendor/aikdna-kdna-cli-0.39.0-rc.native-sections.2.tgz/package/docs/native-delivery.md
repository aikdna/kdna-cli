# Exact native CLI delivery

The unpublished CLI candidate `0.39.0-rc.native-sections.2` uses Core
`0.36.0-rc.r2.7` and Read `0.11.0-rc.r2.7`. The CLI package includes its support
guides and the synthetic author example. Its exact archive and the complete
offline host are delivered separately; no registry release or download service
is announced here.

Obtain an authorized delivery containing `archives.json`, `package.json`,
`package-lock.json` and a `vendor/` directory with twelve exact `.tgz` files.
Before installing, verify each archive's length, SHA256 and npm integrity against
the delivered receipt. The host and lock must select those same twelve archives,
including this CLI candidate, with relative `file:vendor/` locations. Same-version
checkouts and older archive receipts cannot substitute for those bytes.

Use Node `22.22.3` for the reproducible environment. From the delivery directory:

```sh
npm ci --offline --ignore-scripts --omit=optional --no-audit --no-fund
node node_modules/@aikdna/kdna-cli/src/cli.js --help
node node_modules/@aikdna/kdna-cli/examples/native-workflow.cjs node_modules/@aikdna/kdna-cli/examples/team-update/author.json ./team-update-output
```

The recipe resolves the public CLI export from the current host directory. It
requires a new output directory and keeps both original and revised files.
See the [author example](../examples/team-update/README.md) for the disclosed
content, same-session expansion and full Source revision behavior. A successful
scripted run does not prove that a person or another Agent used the content.

The CLI's exact companion binding records Core archive SHA256
`a1468817d6725bbdd1412d7afced297f927e92def8b7bc4109dcc3b432bedef0`
and Read archive SHA256
`a028c653a6fa6b94c970490296b6ab77dc3e18b3912b42796560c998c2cb3f06`.
The candidate's own archive identity must come from its delivered receipt.
Earlier archive lists and host templates describe their own byte identities;
they do not identify this combination. Preserve a complete older set for rollback
rather than mixing archives or reusing sessions and handles across hosts.

`cbor-extract` is optional in `cbor-x` and is excluded with `--omit=optional`.
No compiled acceleration is delivered by this host, and install scripts remain
disabled. Core's reference API and live checkout are separate surfaces from the
native archive combination. There is no retired loader fallback.

## License delivery

Keep LICENSE and NOTICE files from the KDNA packages and preserve
third-party license files. KDNA code is Apache-2.0; documentation and examples
are CC BY 4.0 as stated in NOTICE. Keep the supplied LICENSE-DOCS text with
the complete delivery. The delivery receipt records declared licenses and
their archive members. Most dependencies declare MIT; `fast-uri` declares
BSD-3-Clause and `pako` declares `(MIT AND Zlib)`. These coordinates do not replace
the license terms.

Technical installation, file saving and asset admission do not establish author
confirmation, task adoption, action permission or publication approval.
